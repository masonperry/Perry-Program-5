#Player Class, there is no object yet.
class player_info(object):
    #enables 2 arguments
    def __init__(self, entity, description):
            self.entity = entity
            
    #define "Get Entity"
    def getEntity(self):
            return self.entity
        
    #define "Get Description"      
    def getDescription(self):
            return self.description
        
    #define string
    def __str__(self):
            return "%s is a %s" %(self.description, self.entity)

