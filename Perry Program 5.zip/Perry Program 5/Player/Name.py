#import player_info from Player.py
from Player import player_info

#name class, player_info is the object
class names(player_info):

   #init function and 5 arguments
   def __init__(self, entity, species, experience, health, attack_damage):
      player_info.__init__(self, entity, species)
      self.name = entity
      self.species = species
      self.experience = experience
      self.health = health
      self.attack_damage = attack_damage

   #call string
   def __str__(self):
      return ("%s is a %s. Is %s, has %s, and has an attack damage of %s." %(self.name, self.species, self.experience, self.health, self.attack_damage))


