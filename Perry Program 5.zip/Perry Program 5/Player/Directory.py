from Player import player_info
from Name import names

#Main Protagonists Block
print("Main Characters")
def character1():
    inferno = names("Inferno", "Sorcerer", "Level 1", "25HP", "-3")
    print(inferno)
character1()

def character2():
    shadow_Wolf = names("Shadow Wolf", "Werewolf", "Level 1", "25HP", "-5")
    print(shadow_Wolf)
character2()

def character3():
    theHuntress = names("The Huntress", "Human", "Level 1", "25HP", "-3")
    print(theHuntress)
character3()
#####


print(" ")


#Main Antagonist Block
print("Villain")
def character4():
    evilQueen = names("Queen Cora", "Sorceress", "Level 10", "80HP", "-7")
    print(evilQueen)
character4()
#####


print(" ")


#NPCs Block
print("Non Playable Characters")
def nonPlayableCharacters():
    shopKeeper = names("The Shop Keeper", "Human", "Level 6", "15HP", "0")
    castleGuard = names("The Guard", "Human", "Level 17", "30HP", "-5")
    servant = names("The Servant", "Human", "Level 4", "20HP", "-2")
    prisoner = names("The Prisoner", "Human", "Level 4", "10HP", "-1")
    print(shopKeeper)
    print(castleGuard)
    print(servant)
    print(prisoner)
nonPlayableCharacters()
#####


print(" ")


#Enemies Block
print("Enemies")
def darkEntities():
    shadows = names("Shadow", "made of darkness", "Level 5", "15HP", "-3")
    redKnights = names("Knight", "Human", "Level 10", "30HP", "-4")
    print(shadows)
    print(redKnights)
darkEntities()
#####
