class World(object):
    def __init__(self, grid, spawn)
        self.entity = entity

    def getEntity(self):
            return self.entity

    def placeGrid(self):
            return self.entity

    def spawnEntity(self):
            return self.spawn

    def __str__(self):
            return "Welcome to %s, %s is %s." %(self.entity, self.grid, self.spawn)
    
