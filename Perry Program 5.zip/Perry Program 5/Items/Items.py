#Treasure Class there is no object, yet.
class treasure(object):
    #enable self to 2 arguments
    def __init__(self, entity, description):
            self.entity = entity

    #define "Get Entity"
    def getEntity(self):
            return self.entity
        
    #define "Get Description"      
    def getDescription(self):
            return self.entity

    def pickup(self):
            return self.entity

    def dropLocation(self):
            return self.entity
        
    def equip(self):
            return self.entity
        
    def unequip(self):
            return self.entity
        
    def wearArmor(self):
            return self.entity

    def removeArmor(self):
            return self.entity
        
    def lookat(self):
            return self.entity

    def eat(self):
            return self.entity

    def inInventory(self):
            return self.entity

#call string to return self description and entity.
    def __str__(self):
            return "%s is a %s: %" (self.description, self.entity)
