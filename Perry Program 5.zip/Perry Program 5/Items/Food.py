#Imports treasure from items so the code recognizes food is a treasure.
from Items import treasure

#subclass food is a treasure object
class food(treasure):

#init fuction to enable self to 4 arguments
    def __init__(self, entity, description, value, nutrition):
        treasure.__init__(self, entity, description)
        self.description = description
        self.value = value
        self.nutrition = nutrition

#Calls String
    def __str__(self):
            return ("This %s is worth %s gold coins, and offers %s nutrition." %(self.description, self.value, self.nutrition))
