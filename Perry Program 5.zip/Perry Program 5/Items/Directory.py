#Call all the other files into this portion.
from Items import treasure
from Weapons import weapon
from Armory import armor
from Food import food
from Bank import gold


#Weapons Block
print("Weapons") #to organize the layout

def swordsman():
    #variable       Object  describe, Worth ,Damage
    sword = weapon("Entity", "Sword", "200", "2")  
    print(sword)
swordsman()

def archer():
    #variable              Object,      describe,    Worth ,Damage
    bow_and_arrow = weapon("Entity", "Bow and Arrow", "150", "4")
    print(bow_and_arrow)
archer()

def mage():
    #variable       Object,  describe, Worth, Damage
    magic = weapon("Entity", "Staff",  "300", "6")
    print(magic)
mage()
#######


print(" ")


#Armor Block
print("Armor")

def leather():
    #variable             Object,   Descrition,      Worth, Protection
    leather_chest = armor("Entity", "Leather Tunic", "25", "25%")
    #variable             Object,      Descrition      Worth, Protection
    leather_legs  = armor("Entity", "Leather leggings", "15", "25%")
    print(leather_chest)
    print(leather_legs)
leather()

print(" ")

def chainmail():
    #variable            Object,    describe,   Worth, Protection
    chain_chest = armor("Entity", "Chain Tunic", "50", "50%")
    #variable            Object     describe,      Worth, Protection
    chain_legs  = armor("Entity", "Chain Leggings", "35", "25%")
    print(chain_chest)
    print(chain_legs)
chainmail()

print(" ")

def enchanted_cloak():
    #variable      Object, describe, Worth, Protection
    cloak = armor("Entity", "Cloak", "100", "99.99999%")
    print(cloak)
enchanted_cloak()
#######


print(" ")


#Food Block
print("Food")

def grapes():
    #variable          Object,     describe,      Worth, saturation
    red_grapes = food("Entity", "Vine of Grapes", "10", "35%")
    print(red_grapes)
grapes()

print(" ")

def pig():
    #variable       Object,  describe,  Worth, saturation
    raw_ham = food("Entity", "Raw Ham", "10", "15%")
    #variable          Object,  describe,    Worth, saturation
    cooked_ham = food("Entity", "Cooked Ham", "15", "30%")
    print(raw_ham)
    print(cooked_ham)
pig()

print(" ")

def chicken():
    #variable           Object,  describe,     Worth, saturation
    raw_chicken = food("Entity", "Raw Chicken", "15", "20%")
    #variable             Object,     describe,      Worth, saturation
    cooked_chicken = food("Entity", "Cooked Chicken", "20", "40%")
    print(raw_chicken)
    print(cooked_chicken)
chicken()
#######


print(" ")


#Gold Block
def finances():
    #variable       Object, amount, descrition
    wallet = gold("Entity", "1000", "Gold coins")
    print(wallet)
finances()
#######
