#import treasure from items.py
from Items import treasure

#subclass armor is a treasure object
class armor(treasure):

#enable self with 4 arguments
    def __init__(self, entity, description, value, protection):
        treasure.__init__(self, entity, description)
        self.description = description
        self.value = value
        self.protection = protection

#call string and return
    def __str__(self):
            return ("A %s is worth %s gold coins, and offers %s protection." %(self.description, self.value, self.protection))
