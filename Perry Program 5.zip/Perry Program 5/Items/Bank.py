#import treasure from items.py
from Items import treasure

#subclass gold is a treasure object
class gold(treasure):

#enable self, with 3 arguments
    def __init__(self, entity, description, value):
        treasure.__init__(self, entity, description)
        self.description = description
        self.value = value

#call string
    def __str__(self):
            return ("You have %s %s in your wallet. Spend wisely!" %(self.description, self.value))


