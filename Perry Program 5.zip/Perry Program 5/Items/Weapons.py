#Import Treasure class from Items.py
from Items import treasure

#sub class weapons is a treasure, and treaure is now the object
class weapon(treasure):

#enable self, to associate with 4 arguments
    def __init__(self, entity, description, value, damage):
        treasure.__init__(self, entity, description)
        self.description = description
        self.value = value
        self.damage = damage

#return String function      
    def __str__(self):
            return ("A %s is worth %s, and deals %s health damage." %(self.description, self.value, self.damage))
